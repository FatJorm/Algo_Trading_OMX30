# python-avanza-scraper
Scrape stock info from avanza.se


requires BeautifulSoup and Requests
